from Model.ChatModel import ChatModel
from Model.CityModel import CityModel
from Model.CultivationSessionModel import CultivationSessionModel
from Model.FarmerModel import FarmerModel
from Model.LandModel import LandModel
from Model.ProvinceModel import ProvinceModel
from db import db
from flask import jsonify,request
from Services.NotificationHelper import NotificationHelper

class LandController:
    @staticmethod
    def AddLand():
        try:
            data=request.get_json()
            city_name = data['city_id']
            city = CityModel.query.filter(CityModel.city_name == city_name).first()
            city_id = city.city_id
            data['city_id'] = city_id
            NewLand=LandModel(**data)
            db.session.add(NewLand)
            db.session.commit()
            
            NotificationHelper.land_added_notification(
                NewLand.farmer_id, 
                NewLand.land_name, 
                NewLand.landmark or city_name
            )
            
            return jsonify('Land added!'),200
        except Exception as e:
            return jsonify( str(e)),500

    @staticmethod
    def DeleteLand():
        lid=request.form['id']
        try:
            land = LandModel.query.filter(LandModel.land_id==lid).first()
            farmer_id = land.farmer_id if land else None
            land_name = land.land_name if land else "Unknown"
            
            LandModel.query.filter(LandModel.land_id==lid).delete()
            db.session.commit()
            
            if farmer_id:
                NotificationHelper.land_deleted_notification(farmer_id, land_name)
            
            return jsonify('Land deleted!'),200
        except Exception as e:
            return jsonify( str(e)),500
    @staticmethod
    def getLandWithCurrentSession(id):
        fid=id
        try:
            Lands=(db.session.query(LandModel.land_name,LandModel.land_id,CultivationSessionModel.cultivation_session_id).join(CultivationSessionModel,LandModel.land_id==CultivationSessionModel.land_id).filter(CultivationSessionModel.session_status!="Harvest",LandModel.farmer_id==fid)).all()
            LandList=[]
            if Lands:
                for land in Lands:
                    LandList.append({"Land Name":land.land_name,
                                     "id":land.land_id,
                                     "cultivation_session_id":land.cultivation_session_id
                                     })
                return jsonify(LandList),200
            return jsonify("No Current Session exist"),404
        except Exception as e:
            return jsonify(str(e)),500


    @staticmethod
    def editLand():
        data=request.get_json()
        lid=data['id']
        city_name=data['city_name']
        try:
            city=CityModel.query.filter(CityModel.city_name==city_name).first()
            city_id=city.city_id
            existingland=LandModel.query.filter(LandModel.land_id==lid).first()
            if existingland and city_id:
                existingland.land_id=lid
                existingland.land_name=data['land_name']
                existingland.years_of_cultivation=data['years_of_cultivation']
                existingland.soil_type=data['soil_type']
                existingland.source_of_water=data['source_of_water']
                existingland.land_in_acres=data['land_in_acres']
                existingland.city_id=city_id
                db.session.commit()
                
                NotificationHelper.land_updated_notification(existingland.farmer_id, data['land_name'])
                
                return jsonify("Land edited!"),200
            return jsonify("Land not found"),404
        except Exception as e:
            return jsonify(str(e)),500

    @staticmethod
    def GetallLands(id):
        f_id=id
        landsLsit=[]
        try:
            Lands=LandModel.query.filter(LandModel.farmer_id==f_id).all()
            if Lands:
                for l in Lands:
                    city=CityModel.query.filter(CityModel.city_id==l.city_id).first()
                    landsLsit.append({
                        'land_id':l.land_id,
                        'land_name':l.land_name,
                        'years_of_cultivation':l.years_of_cultivation,
                        'soil_type':l.soil_type,
                        'source_of_water':l.source_of_water,
                        'land_in_acres':l.land_in_acres,
                        'city_Name':city.city_name,
                        'landMark':l.landmark,
                    })
                return jsonify(landsLsit),200
            else:
                return jsonify('Land not found against farmer!'),404
        except Exception as e:
            return jsonify( str(e)),500

    @staticmethod
    def getLandByID(id):
        lid=id
        try:
            land=(db.session.query(
                LandModel.land_name,LandModel.land_in_acres,LandModel.farmer_id,LandModel.years_of_cultivation,LandModel.soil_type,LandModel.source_of_water,LandModel.land_in_acres,LandModel.city_id,LandModel.landmark,LandModel.land_Status,
                CityModel.city_name,ProvinceModel.province_name
            ).join(CityModel,LandModel.city_id==CityModel.city_id).join(ProvinceModel,CityModel.province_id==ProvinceModel.province_id).filter(LandModel.land_id==lid)).first()
            if land:
                return jsonify({
                            'Province':land.province_name,
                            'land_name':land.land_name,
                            'years_of_cultivation':land.years_of_cultivation,
                            'soil_type':land.soil_type,
                            'source_of_water':land.source_of_water,
                            'land_in_acres':land.land_in_acres,
                            'city_Name':land.city_name,
                            'landMark':land.landmark,
                            "land_Status":land.land_Status
                        }),200
            return jsonify("Land Not found"),404
        except Exception as e:
            return jsonify( str(e)),500
